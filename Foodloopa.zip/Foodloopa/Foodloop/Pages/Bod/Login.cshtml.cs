using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Data.SqlClient;

namespace Foodloop.Pages.Bod
{
    public class LoginModel : PageModel
    {
        private readonly string _connectionString =
            "Server=mssql17.unoeuro.com,1433;Database=kunforhustlers_dk_db_test;User Id=kunforhustlers_dk;Password=RmcAfptngeBaxkw6zr5E;TrustServerCertificate=True;Encrypt=True;";

        [BindProperty]
        public string Email { get; set; } = string.Empty;

        [BindProperty]
        public string Password { get; set; } = string.Empty;

        public string Message { get; set; } = string.Empty;

        public void OnGet() { }

        public IActionResult OnPost()
        {
            if (string.IsNullOrEmpty(Email) || string.IsNullOrEmpty(Password))
            {
                Message = "Udfyld både email og kodeord.";
                return Page();
            }

            using var conn = new SqlConnection(_connectionString);
            conn.Open();

            var cmdBod = new SqlCommand(
                "SELECT BodId, Navn FROM Boder WHERE Email = @Email AND LoginKode = @Password",
                conn
            );
            cmdBod.Parameters.AddWithValue("@Email", Email);
            cmdBod.Parameters.AddWithValue("@Password", Password);

            using var reader = cmdBod.ExecuteReader();
            if (reader.Read())
            {
                int bodId = reader.GetInt32(0);
                string bodNavn = reader.GetString(1);

                // Gem i session
                HttpContext.Session.SetInt32("BodID", bodId);
                HttpContext.Session.SetString("BodNavn", bodNavn);

                // SPECIAL CASE → veganvibes bruger sendes til Bodside
                if (Email.ToLower() == "hello@veganvibes.dk" && Password == "login05")
                {
                    return RedirectToPage("/Bod/Bodside");
                }

                // Alle andre logges ind normalt og sendes til AdminDashboard
                return RedirectToPage("/Bod/AdminDashboard");
            }

            Message = "Login mislykkedes – prøv igen.";
            return Page();
        }
    }
}
