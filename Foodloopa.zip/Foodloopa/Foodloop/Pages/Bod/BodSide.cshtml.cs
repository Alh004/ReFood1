using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Data.SqlClient;
using System.Collections.Generic;

namespace Foodloop.Pages.Bod
{
    public class BodsideModel : PageModel
    {
        private readonly string _connectionString =
            "Server=mssql17.unoeuro.com,1433;Database=kunforhustlers_dk_db_test;User Id=kunforhustlers_dk;Password=RmcAfptngeBaxkw6zr5E;TrustServerCertificate=True;Encrypt=True;";

        // Statistik
        public decimal TotalOmsætning { get; set; }
        public int TotalOrdrer { get; set; }
        public int TotalRetter { get; set; }

        // Ordrer og OrdreLinjer
        public List<OrderDto> Orders { get; set; } = new();
        public List<OrdreLinjeDto> OrdreLinje { get; set; } = new();

        public void OnGet()
        {
            using var conn = new SqlConnection(_connectionString);
            conn.Open();

            // Statistik
            using (var statCmd = new SqlCommand(@"
                SELECT 
                    ISNULL(SUM(r.Pris * ol.Antal), 0),
                    COUNT(DISTINCT o.OrdreID),
                    ISNULL(SUM(ol.Antal), 0)
                FROM Ordrer o
                JOIN OrdreLinje ol ON o.OrdreID = ol.OrdreID
                JOIN Retter r ON ol.MadID = r.MadID", conn))
            using (var statReader = statCmd.ExecuteReader())
            {
                if (statReader.Read())
                {
                    TotalOmsætning = statReader.IsDBNull(0) ? 0 : statReader.GetDecimal(0);
                    TotalOrdrer = statReader.IsDBNull(1) ? 0 : statReader.GetInt32(1);
                    TotalRetter = statReader.IsDBNull(2) ? 0 : statReader.GetInt32(2);
                }
            }

            // Hent ordrer
            using (var ordreCmd = new SqlCommand("SELECT OrdreID, KundeID, Dato, Status FROM Ordrer ORDER BY Dato DESC", conn))
            using (var ordreReader = ordreCmd.ExecuteReader())
            {
                while (ordreReader.Read())
                {
                    Orders.Add(new OrderDto
                    {
                        OrdreID = ordreReader.GetInt32(0),
                        KundeID = ordreReader.GetInt32(1),
                        Dato = ordreReader.GetDateTime(2),
                        Status = ordreReader.IsDBNull(3) ? "Ny" : ordreReader.GetString(3)
                    });
                }
            }

            // Hent ordrelinjer
            using (var lineCmd = new SqlCommand("SELECT OrdreID, MadID, Antal, Pris FROM OrdreLinje ORDER BY OrdreID DESC", conn))
            using (var lineReader = lineCmd.ExecuteReader())
            {
                while (lineReader.Read())
                {
                    OrdreLinje.Add(new OrdreLinjeDto
                    {
                        OrdreID = lineReader.GetInt32(0),
                        MadID = lineReader.GetInt32(1),
                        Antal = lineReader.GetInt32(2),
                        Pris = lineReader.IsDBNull(3) ? 0 : lineReader.GetDecimal(3)
                    });
                }
            }
        }
        
        

        // Opdater status uden at skifte side
        public IActionResult OnPostUpdateStatus(int ordreId, string status)
        {
            using var conn = new SqlConnection(_connectionString);
            conn.Open();

            var cmd = new SqlCommand("UPDATE Ordrer SET Status=@status WHERE OrdreID=@ordreId", conn);
            cmd.Parameters.AddWithValue("@status", status);
            cmd.Parameters.AddWithValue("@ordreId", ordreId);
            cmd.ExecuteNonQuery();

            return RedirectToPage(); // Bliv på samme side
        }

        public class OrderDto
        {
            public int OrdreID { get; set; }
            public int KundeID { get; set; }
            public DateTime Dato { get; set; }
            public string Status { get; set; } = "Ny";
        }

        public class OrdreLinjeDto
        {
            public int OrdreID { get; set; }
            public int MadID { get; set; }
            public int Antal { get; set; }
            public decimal Pris { get; set; }
        }
    }
}
 